From:  Stacey E. Mills, W4SM
Date:  2002-08-30

About IPSWin.ZIP
----------------

Contents
--------
ReadMe1st.txt     This file
ReadMe.txt        General notes about IPS-Win

The files in this zip should be placed in the following directories on your drive of choice:

IPS-Win   (main directory)
  Ips-MW.bin      IPS emulator kernel, German instructions
  Ips-MWe.bin     IPS emulator kernel, English instructions
  IPSWin.cfg      Configuration file for Ips-Win
  IPS_Win.exe     IPS-Win program

Input  (subdirectory of IPS-Win)
  Tak-m.txt       TAK recursion program, W4SM
  GS2001.txt      IPS/Atari tracking program
  Keps.txt        IPS/Atari keps for AO-40
  
Binary (subdirectory of IPS-Win)
  ...create this directory for $SAVE, $LOAD use.
  ...it is empty for now.  


