NOTE:  These progams are for the NEW camera with the FPGA buffer interface
______________________________________________________________________________

Note:  See also Camera.Readme



SA-1100 Camera ARM Coded utilities
----------------------------------
These are sources for ARM code versions of camera drivers/processors.


 Source     Binary        Size    Comment
 ----------------------------------------------------------------------
 SRC_Snap   RAM:SnapCode  176     Takes Raw image 
 SRC_Corr   RAM:CorrCode   84     Applies calibration file to raw image 
 SRC_Diff   RAM:DiffCode  200     Subtracts two raw images 
 SRC_Idle   RAM:IdleCode   92     Camera random addressing during idle 
 ----------------------------------------------------------------------

All code is relocatable, but will usually be placed in the IPS space 0-#FFFF.

For example, SNAP is done like this:

  176 USERCODE  SNAP       ( Create definition )
  ? SNAP   0  D2FILE-INST  ( Prepare D handler )
  (  *** Now upload SnapCode as a D-block *** )
  
Similarly with CORR  DIFFSNAP and IDLE.

The programs SNAP, CORR, DIFFSNAP and IDLE in this directory are 2-block IPS
binary files that contain the definition command plus the D-block.  Assuming
that D-Utils are loaded, you can upload these directly.

CAM_UTILS (8 blocks) is the concatenation of the above 4 programs.
______________________________________________________________________________

SNAP is an ARM coded version of SNAPSHOT, and takes a raw 512x512 image.

SNAP takes 1.2s to execute.  0.75s of this is due to extra delays built in
to slow down the camera X addressing from the specified 160ns to 2.9 us !

Note that the IPS clock is stalled while this routine is running, so it will
appear to lose 1.2s per call.

The syntax of SNAP is:

      <addr LSW> <addr MSW> SNAP

where <addr> specifies the 32-bit address where the image data is to be placed.
______________________________________________________________________________

CORR is an ARM coded CORRECT, and applies the ROM based camera calibration file
to the raw image at a specified address.

CORR takes 78ms to execute, so the IPS clock will lose a similar time.

The syntax of CORR is:

      <addr LSW> <addr MSW> CORR

where <addr> specifies the 32-bit address where the image data is placed.

Example:  to correct an image at 0x1000 0000 use:

        #0 #1000 CORR
______________________________________________________________________________

DIFFSNAP is like SNAP+CORR, but uses an existing raw image in RAM as the
calibration file.   Typically this would be used to take images of the stars,
where they will have moved slightly.

DIFFSNAP takes ~1.2s to execute, so the IPS clock will lose a similar time.

The syntax of DIFFSNAP is:

      <addr LSW> <addr MSW> DIFFSNAP

where <addr> specifies the 32-bit address where the image data is placed.

Example:  to difference two images at 0x1000 0000

        #0 #1000 DIFFSNAP
______________________________________________________________________________

IDLE addresses the camera pixels at a random location every time it is called.
This keeps the camera AGC system at the mean image brightness.  The routine
takes about 200ns to execute.

IDLE should be enchained, or otherwise called regularly, for example:

  7 EINH IDLE
______________________________________________________________________________

2000 Apr 08 [Sat] 2115 utc
jrm
