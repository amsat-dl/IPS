NOTE:  These prorgams are for the NEW camera with the FPGA buffer interface
______________________________________________________________________________


SA-1100 Camera test utilities
-----------------------------
Note:  Much difficulty has been experienced with the camera due to a) AGC
settling, and b) Fuga's timing specifications.

In order to take an image at random, you should take 3 images in series, and
download the 3rd.  This allows the AGC system to settle.  Alternatively,
enchain IDLE, and you can take an image at any time. 

If Fuga's timing diagrams are followed, it should be possible to take an image
in ~0.5s  In fact the quickest we have achieved is ~1.2s.  Delays have been
built into the program SNAP to do this.  If they are reduced, the image acquires
increasingly severe vertical lines, and speckling.  If the delays are increased,
from the value used in SNAP, there is no improvement to the image.

Note that these IPS coded utilities are essentially for reference and simple
testing.  For speed and consistency you should preferably use the ARM coded
versions.  See Sources.ReadMe.


Programs: CAM_ON and CAM_OFF
----------------------------
These turn power to the camera on and off.  IPS-EM defaults to OFF.

Program: SNAPSHOT
-----------------
This IPS program reads 256 kBytes from the camera port, and places them in
unprotected mass RAM at 0x1000 0000 to 0x1003 FFFF.

The full camera address space is addressed; Y=0 to 511, X = 0 to 511, and takes
about 5 s.

No calibration correction is applied.

Program: CORRECT
----------------
Takes 256K image at 0x1000 0000 and applies calibration file located in
Flash ROM at 0x10A0 0000.  Result is replaced at 0x1000 0000.  This image is
ready for direct download and display, or may be JPEG'd.

Program: FUGAtest
-----------------
Takes photo (three times, to let the AGC settle), applies calibration
correction and emits 256K byte image at 115,200 baud on the Serial Port.

The calibration file is assumed to be in ROM 1, i.e. at address 0x10A0 0000

The corrected picture is placed in mass RAM at 0x1000 0000.  If desired this
can be compressed using the default JPEG program.

The enchained FUGADUMP is only useful for engineering models with a serial
port. In the P3D flight computer you would use the D-system to dump the image
from 0x1000 0000, or JPEG at 0x10000 via the beacon.

File: SCRATCHPAD
----------------
Bits and pieces used for fiddling about with camera.


Acorn Applications: !Correct and !Show
--------------------------------------
!Corrrect takes a raw 512K image, applies the correction file, and displays
the result.

!Show displays an already corrected file.

Directory: Sources
------------------
These are sources for ARM code versions of camera drivers/processors.

See ReadMe therein.

jrm
2000 Mar 03 [Fri] 1524 utc