Speed
-----
This is a test program used to calculate the number of chain cycles executed
per second.

Need JRM to explain how to use it ... if I can remember.

jrm
1998 Jun 28 [Sun] 1026 utc
