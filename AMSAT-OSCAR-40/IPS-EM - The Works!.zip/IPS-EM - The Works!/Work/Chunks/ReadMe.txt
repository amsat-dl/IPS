                      IPS Definitions Chunk Utilities

                          by James Miller G3RUH


This directory contains utilities to create blocks of IPS definitions called
Chunks, and copy them from ROM to RAM to ground (GND) in any combination.  The
chunk format is described in the file:   Docs.Format

The utilities are as follows; each is commented in its listing.  Despite their
apparent verbosity, all utilities can be white-space stripped to fit in
1 block.

Note that temporary buffers are sometimes used, by default at #8000.  You
are responsible for checking that this area is free.

If material is being accessed from flash-rom, you must edit the utility
variable ROMOFF to point to the desired address.

  CREATECHNK  How to create a chunk of IPS definitions.
  
  ROM2RAM  )                           ( flash to ram
  ROM2GND  )                           ( flash to downlink
  RAM2ROM  )  How to copy a chunk from ( ram to flash rom
  RAM2GND  )                           ( ram to downlink
  GND2ROM  )                           ( uplink to flash rom
  GND2RAM  )                           ( uplink to ram.
  
Where the destination is "ram", the loaded definitions are added to IPS, and may
be executed exactly as though they had been compiled from source in the
conventional way.

2000 Feb 16 [Wed] 2256 utc
<end>

