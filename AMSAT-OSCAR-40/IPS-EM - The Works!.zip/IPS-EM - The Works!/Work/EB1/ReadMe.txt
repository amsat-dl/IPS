Program: EB1
============

This is a program to read the EB1 and retransmit it on the EB2.

 Start with:  EB1_ST
 Stop with:   EB1_STOP

There is a processing delay of 1 block (12 seconds).

Description
-----------
The program has two parts:

 EB1_SERVICE is enchained at KETTE 0, and is responsible for reading the EB1
             block and placing it in the buffer pointed to by $EB1BU .
 EB1_SEND    is responsible for transmitting that buffer via the EB2 beacon.

Communication between the two parts is via the EB1_FULL flag; when the whole
buffer has been collected, the flag is set to 1; EB1_SEND picks this up, and
will cause the block to be transmitted on the EB2 beacon, and then clear the
EB1_FULL flag.

The program is started with EB1_ST .

This ensures the GPIO Rising Edge Register (GRER) has the necessary EB1 bits
enabled, clears the EB1 hardware control bistables and any GPIO Edge Detected
Register (GEDR) bits.  It then clears both the program control flags
EB1_SYNCRCVD and EB1_FULL.

Enchained routine EB1_SERVICE repeatedly tests the state of the EB1 sync vector
detected bit, and when found, clears the sync hardware bistable, reads and
discards the pending EB1 word (it's the sync vector PN31), clears GEDR bits,
initialises the EB1_WORDCOUNT to 0, and sets the EB1_SYNCRCVD flag.

Now the routine repeatedly tests for a new EB1 word.  If found, it is read,
placed in the buffer and the GEDR "need read" bit cleared.  This process
repeats until 129 words (ie a block + crcc) have been received.

When 129 words have been collected, their crcc is checked, and if OK (or if the
EB1_IGNORE flag is 1) the flag EB1_FULL is set, and the EB1_SYNCRCVD cleared,
thus allowing the whole cycle to start over again.

The program can be stopped with  EB1_STOP .


Notes
-----
It is not necessary to re-transmit the buffer on the EB2 beacon;  the buffer
material could be used by the IHU-2 as data, perhaps acting upon it, or simply
logging it to the 8MB mass RAM.

To collect the EB1 data only, start the program with commands as below, rather
than EB1_ST on its own:

  A-COMPOSER     ( get existing value )
  EB1_ST         ( start data collection )
  ? A-COMPOSER ! ( restore original value)
  
The program works by polling the EB1sync and EB1read bits in the SA-1100 GEDR
register. It is implicit that slow tasks, like picture taking, are not running,
otherwise we will lose words.  If this is a problem, then an equivalent program
would be required which ran under interrupt service. 

jrm
2000 Apr 10 [Mon] 0914 utc
