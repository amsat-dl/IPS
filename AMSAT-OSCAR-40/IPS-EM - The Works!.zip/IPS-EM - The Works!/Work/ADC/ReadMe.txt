
ADC>SER
-------
A test program to read the 8 channel ADC and place the results on the
115,200 baud serial port 6.25 times/s in a format suitable for direct use by the
BASIC anaysis program, "Statistics".

DATA 1963,2016,2422,3191,1473,3301,1857,2489
DATA 1964,2018,2413,3193,1477,3305,1857,2489
DATA 1960,2017,2416,3191,1483,3308,1857,2489
.
.

It is possible for the ADC and SA-1100 FIFO to get confused.  Very possible.
Channel 7 should show the value ~2500 (5 volts).  If it doesn't, send the
command   #006C #8007 GETW PWEG  a few times until it /does/ show ~2500 !

ADC>SER-C
---------
As above, but white-space stripped.

ADC>BCN, ADC>BCN-C
------------------
As above but to 400 bps beacon.  8 data lines to a block.  Data collection
takes 1.12s; but downlink takes 14.4s/block
______________________________________________________________________________

TEMP>SER
--------
Reads temperature sensors via ADC channel 6 and the thermistor multiplexer.
Output like:

DATA 2007,2000,1980,13
DATA 2007,2000,1980,13
DATA 2007,2000,1981,13

TEMP>SER-C
----------
As above, but white-space stripped.

TEMP>BCN, TEMP>BCN-C
--------------------
As above but to 400 bps beacon, and two lots of output per line:

DATA 2007,2000,1980,13,2007,2000,1980,13
DATA 2007,2000,1980,13,2007,2000,1980,13
DATA 2007,2000,1981,13,2007,2000,1981,13
  
______________________________________________________________________________

SRC_ADC
-------
BASIC program to create ADC 31250 Hz IRQ handler for post-launch data
collection software.  See listing for buffer assignations.

Test_ADC
--------
IPS tester for above.


jrm
2000 May 19 [Fri] 1326 utc
