                          9600 bps FSK Modulator

                          by James Miller G3RUH

                                2000 May 04

                             * Introduction
                             * User Interface
                             * Installation
                             * Customising
                             * Restoration
                             * Software Description


Introduction
------------
The file SRC_9600 creates an ARM code binary program to replace the default
IPS-EM IQ Modulator Interrupt Handler.  The code is fully relocatable.

The handler outputs a user-defined area of memory in scrambled 8N1 "RS232"
format at 9600 baud using direct FM.    This is the same as used in packet
radio systems (terrestrial, UoSAT and P3D RUDAK), and allows users to take an
RS232 stream directly from the output of their 9600 baud packet modems.

Optionally, NRZ->NRZI encoding can be selected.

Selection number 10 from the standard collection is used.  This is an 8-bit long
FIR and is synthesised with 13 segments per bit.  The FM deviation, which is
user adjustable, is +/- 3 kHz pk.

Under IPS-EM, this handler uses 12.2% of machine time.


User Interface
--------------
You configure the handler with 4 words, offset from the start of the code as
follows:

  Offset                              |
  Hex   Size    Configures            |   Default         Comment
 -------------------------------------+-------------------------------------
  +1C   word    Start address/pointer |  &000004FB        EBU (incl. sync)
  +20   word    End address+1         |  &00000702        incl. crcc
  +24   word    Halt/go               |   0               0 = halt  1 = go
  +28   word    Deviation constant    |   6341            +/- 3 kHz pk
  +90   byte    NRZ->NRZI on/off      |   on              See notes
 -------------------------------------+-------------------------------------

+24 Halt/go controls transmission.  When 0, stop polarity is sent to the serial
output stream, and data pickup is halted.

When the user sets Halt/go to non-zero (i.e. "go"), data is transmitted from
the address at +1C to the address at +20 exclusive.  When all data has been
sent, the handler resets Halt/go to 0.

The user may control Halt/go at any time;  if set to "Halt" mid transmission,
the stream halts;  +1C contains the current pointer, i.e the address from where
data transmission will be resumed if Halt/go is then set to "go".

Addresses are 32-bit, and byte aligned.  The minimum transmission is 1 byte.

+------------------------------------------------------------------------------+
| WARNING:  There are no checks on addressing.  In particular, if an address   |
| is negative, the IHU-2 will crash with a Data Abort.  Make sure that any     |
| address you give anything EVER is in the range 0x0000 00000 - 0x1FFF FFFF !! |
+------------------------------------------------------------------------------+

You may control the peak FM deviation by altering the constant at +28 pro-rata.
This constant should be a positive number.

NRZ->NRZI encoding of the data allows the ground station user system to be
insensitive to arbitrary polarity inversions in the channel, and requires the
use of the NRZI->NRZ converter in an associated TNC or otherwise to be added to
the modem->computer interface.  To disable encoding, write the byte #0 to +B8;
to enable encoding, write the byte #1 to +B8.  Here we are patching code, so
you MUST then flush the caches with the IPS word $FLUSH (or SWI 0 in arm code).


Installation (for IPS-EM v0.12)
-------------------------------
   ***   The following IPS fragments are in command file: FM9600  ***

1. Run SRC_9600 to create the file FM9600 in RAM disc.

2. Convert FM9600 to D-blocks.  This is file UpDblocks , in this directory.

3. Prepare the D-handler with the command:

   #AA00 #0  D2FILE-INST

4. Upload   UpDblocks  (10 blocks)

   Note: Address #AA00 is used in this example, but it could be anywhere, and
   is not confined to normal IPS space 0-#FFFF.

5. Upload the following:

   #0004 #9005 GETW  VERT #FF7F UND  VERT #0004 #9005 PUTW  (Int OFF )
   #FCAA #E3A0   #00E0 #0000 PUTW  $FLUSH       ( 0xE0: MOV PC,#AA00 )
   #0000 #0000   #05F0 #0800 PUTW                 ( flush fpga logic )
   #0004 #9005 GETW  VERT #0080 ODER VERT #0004 #9005 PUTW   (Int ON )

The IHU-2 will now be transmitting 9600 bps FM with +/- 3 kHz pk deviation,
stop polarity (scrambled) continuous.


Customising
-----------
a) To change address space:  Example 8MB mass ram (2.4 hours transmission!)

   #0000 #1000      #AA1C #0 PUTW   ( start )
   #0000 #1080      #AA20 #0 PUTW   ( end+1 )
   #0001 #0000      #AA24 #0 PUTW   ( 1=go  )

b) To alter deviation:  Default  6341 is  +/- 3 kHz pk. Example:

   8455 ( dev +/- 4.0 kHz ) #0000 #AA28 #0 PUTW

c) to halt addressing and force continuous stop polarity: 

   #0000 #0000      #AA24 #0 PUTW   ( 0=halt  )
   
d) to disable NRZ->NRZI encoding:

            #0   #AA90 #0000 PUTB  $FLUSH


Restoration
-----------
To patch out the new IQ modulator handler, and restore the original:

1. Upload:

  ( Turn OFF IQmod interrupts !! )
    #0004 #9005 GETW   VERT #FF7F UND  VERT  #0004 #9005 PUTW

  ( Patch IQmod interrupt handler to original code )
    #E302 #E3A0 (MOV r14,#&08000000) #00E0 #0000 PUTW  $FLUSH

  ( Re-enable IQmod interrupts )
    #0004 #9005 GETW   VERT #0080 ODER VERT  #0004 #9005 PUTW


Software Description
--------------------

1. Implementation
   --------------
The IQ modulator rate is 125,000 interrupts/s.  Conveniently, 13 interrupts
corresponds to 9615 bps, but which is close to 9600 bps, but not /quite/ close
enough for demodulator PLLs to pull in.

48 bits at 9600 bps is exactly 625 interrupts (not 13*48 = 624 as in the
approximation).  Thus, every 48 bits we repeat the previous 1/13th of a bit.
This phase slip is beneath the general noisiness of the RX system.

The service routine therefore works on a loop counter of 13 and the structure
mirrors the G3RUH TX hardware, i.e. shift register, 17-bit scrambler and
look-up table of modulator values MODTAB(I,D), I=0 to 12, D = 0 to 255

On each interrupt:
  Preserve caller's registers
  Get state (indices and pointers)
  Get data D from scrambler register 8-bits)
  Get modulator value from V = MODTAB(I,D)    index = I*256+D
  Scale for required deviation
  Increment phase counter by V*scale
  Look up sin(phase) and cos(phase)
  Send sin/cos to IQ modulator
  Do index operations:
  If I is 13 then
     Get next bit (on bit index 0-9)
     Update NRZI and scrambler, shift data
     If 10 bits shifted out then
        If halt flag is go then
          Get new byte from user memory, adding stop and start bits
          Check user memory pointer and set halt if last
  Save state
  Restore caller's registers
  Return to caller

2. Mechanisation
   -------------
There isn't enough room in page 0 for all this, so it is jumped by poking a
patch into the default IQmod handler  MOV PC,ext_IQmod.  Obviously IQmod
interrupts must be temporarily turned off while this patch code is installed!

Return using  r13!,{r0-1,r8,PC}^ , which is our normal IRQ return instruction.

3. Scaling
   -------
The MODTAB(I,D) modulation table will be bytes and has values 1-255,
representing the range +/-127.  This should correspond to +/- 3 kHz deviation.

Since dF = dph/dt, 3 kHz requires a dph of 3000/125000 rotations/interrupt.
The sincos LUT maps 1 rot = 256 cnts, so we need dph = 6.144 cnt/interrupt max.

We have +/-127 cnts max, which is somewhat larger, so need to scale the
rotation (phase) counter by 1/20.67, which can be approximated with  ~ 3/2^6 or
very accurately by 6341/2^17

Re-scaling can be done with shift+add style multipliers, and then a right shift
division.  However, the MLA instruction offers arbitrary multiply plus
phase+=dph, and executes in only a few cycles, so lets use it.

Multiplying amplitude by 6341 and shifting phase right by 17 maps the values
+-127 to +-3 kHz deviation to within 1 ppm.  Gotta be accurate!

If phase is increasing, the output frequency increases.  There will however be
many frequency translations and thus arbitrary inversions of data polarity
before the ground station 9600 baud demodulator gets its input.

SinCos(phase) table is a 256 entry LUT with the format exactly as required by
the AD7011 (see e.g. FM-MIC).

<end>
