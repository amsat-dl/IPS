                   Upload and Download of Large Files
                   ----------------------------------
                         by James Miller G3RUH

For the IHU-2 there is a need to be able to upload and download large items
of data (large means greater than 512 bytes).

A system has been devised whereby long files or areas of memory are split into
500 byte packets with some header information.  These are called D-blocks.
Utilities exist in IPS for the IHU-2, in BASIC for the RiscPC and in "C" for the
IBM-PC to dissect or re-assemble files.

Directory D-System
------------------
  File2D       Dumps a longer section of memory as "D" blocks (see below)
  D2File       Accepts a large file upload                    (see below)

  File2D-C     File2D stripped of whitespace ( 2 blocks).
  D2File-C     D2File stripped of whitespace ( 2 blocks).

Directory: D-System.Docs
------------------------
  dspecs.zip   D-block specification and examples.

Directory: D-System.D_Utils
---------------------------
  !D-Manager   RiscPC utility to convert  File  to and from  D-blocks

Program: File2D & File2D-C
--------------------------
This is a program to download large chunks of memory from the IHU-2.  It is
invoked with:        ~~~~~~~~

 <Name> <Start L,H> <Length L,H> FILE2D-ST

For example, to download a 512x512 byte camera image from the mass RAM
at 0x1000 0000:

     Filename         Start L,H     Length L,H
   #4A4C ( " LJ "  )  #0000 #1000   #0000 #4    FILE2D-ST

Note that both the Start location, and the file length are 32-bit quantities,
and the filename is mandatory, even if 0x0000, and perhaps should be unique.

This will cause the beacon to start sending "D" blocks with the requested
information.

If your re-builder utility indicates that some segments are missing, send the
command:

  nn BLOCK-COUNT !

which will re-index the download counter to send the segment(s) you require.
Note that BLOCK-COUNT starts from 0 and its maximum value is the Total Number
of D-blocks - 1.

You can stop the download completely with the command:

  ' RUMPELSTILZCHEN ? A-COMPOSER !    ( Command responses only )

This command is also available as Dumper.DumpStop.

You can restart the download with the command:

 ' FILE2D ? A-COMPOSER  !



Program: D2FILE & D2FILE-C
--------------------------
This program handles the upload of large chunks of data or program.  It is
invoked with:            ~~~~~~

 <address LSW, MSW>  D2FILE-INST

and thereafter the program will accept a stream of D-blocks, placing the data
at the address invoked.  Note that the address is a 32-bit quantity.

For example, to upload (say) a 512x512 camera calibration file to mass RAM
at 0x107C 0000:

  #0000 #107C D2FILE-INST

You can request a status report on the upload with the command  D?  This
will return between 2 and 8 items on the stack.  These are:

 - Total number of segments representing the source file
 - Number of segments received
 - Indices of the first 6 segments not yet received, if any.

For example, the status report:
  525     56      44      58      59      60      61      62
means that the the upload is 525 D-blocks long, and that 56 blocks have been
uploaded successfully.  The first "holes" are blocks 44, 58-62.  There are
more missing blocks not listed.  Upload blocks are numbered here from 1 (not 0).

You can resume an upload at any point, and blocks can be uploaded more than
once without problem.

When the upload is complete, the SA-1100 caches are flushed so that if the
data is actually program *code*, it is guaranteed to be placed in memory, and
be thus be accessible as instructions by the processor


jrm
1999 Jul 20 [Tue] 2258 utc
<end>
