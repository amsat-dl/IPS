IPS-EM Downlink Utilities
-------------------------
To make IPS-EM  output material on the EB-2 beacon:

  1. Create a routine (say MYPROG) which will, when called:
  
     a. Marshall its downlink material and place
        it in the 512 byte buffer $EBU
     b. call ETRANSMIT which will then append the block crc
        and start the downlink.
  
  2. Place your routine's address into the constant A-COMPOSER , e.g.
  
        ' MYPROG ? A-COMPOSER !
     

Your routine will now be called whenever the downlink is free, approximately
every 12.64 s.

Examples are included in this directory:

SendBlocks
----------
The program "SendBlocks" transmits 9 memory dumps followed by one message
block on the downlink beacon.

The sequence is controlled on the value of EB-COUNT in routine TLM-TN.
When EB-COUNT = 0, the M block is sent.  Otherwise a dump is made from
the location specified in the variable DUMP.

To stop the downlink process, send a command:

  ' RUMPELSTILZCHEN ? A-COMPOSER !    ( Command responses only )

This is in the file "DumpStop" in the Work.Dumper directory.

The program "SendBlocks" can also be used in the IHU-1, directly after
IPS-C or IPS-D has been loaded.

Q
-
Generates non-stop Q blocks containing a header, and Syspage dump.
You can stop telemetry with  0 TLM  and start it with  1 TLM

TLM/IPS
-------
TLM-TN is a typical telemetry handler for the 400 bps PSK engineering beacon.
It sends a sequence blocks, starting with a telemetry block (Q) and then up
to 8 message (Y) blocks.  The number of blocks in the sequence is user
defined with EB_NUM , which can take values in the range 1-9.  For example,
1 EB_NUM ! would give Q blocks only; 2 EB_NUM ! gives Q plus the first
message block.  Text blocks are uploaded with the commands Y0 , Y1 ... Y7 ;
the digit is stripped off by the handlers.  Telemetry can be turned on with
1 TLM , and off with 0 TLM . 


jrm
2000 Feb 02 [Wed] 1551 utc
