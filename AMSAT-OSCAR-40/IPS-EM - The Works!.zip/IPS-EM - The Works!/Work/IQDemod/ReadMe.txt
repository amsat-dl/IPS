These notes document use of the IHU-2 IQ demodulator via IPS-EM.

See also  !YahuTest.Docs.IHU2_PRM.IQdemod


1. IPS-EM IQ Demodulator Interface
   -------------------------------
When enabled, and after initialisation of the hardware, the IQ demodulator
interrupts are continuous at 31.250 kHz.

  |  As presently coded, the IPS-EM interrupt handler reads the demodulator
  |  data word and places it in a 64K word circular buffer in EDAC RAM,
  |  #0001 0000 - #0005 0000 exclusive with a cycle time of 2.10 seconds.
  |  The current pointer is at #011C.  Later, these addresses will change.
  
1.1 Data word format
    ----------------
    The I and Q data are 15 bits each combined together.  The format is:
    
             I Data              Q data
        IIII IIII IIII III1 QQQQ QQQQ QQQQ QQQ0
        MSB                                 LSB
    
1.2 Demodulator Control
    -------------------
    1. Unjamming FPGA interrupt system.  Sometimes this starts up jammed,
       but can be released once and for all with:
       #05F0 #0800 GETW PWEG           ( Clear IQD_IRD bistable )

    2. Resetting the AD7013 and configuring it:
    
        #0004   2 /   #0 #05E4 #0800 PUTW ( Reset AD7013 chip )
        #2488   2 /   #0 #05E4 #0800 PUTW    ( Configure chip )
        
    3. Set AGC to a reasonable value with:
    
       #2C0                                ( AGC value - 10 bits)
       #40 * #1C +  2 / #0 #05E4 #0800 PUTW    ( Send AGC value )
       
    Items 1,2,3 are in the command file  "InitDemod".
    
  |   Note that the  2 /  is a temporary right shift to compensate for an FPGA
  |   error.  All AD7013 commands require this correction.
    
    4. Set the RX frequency with:
    
       #47AE  #0 ( N LS 16 bits )       #0C10  #0800 PUTW   ( 11.020 MHz )
       #02C1  #0 ( N MS 16 bits )       #0C14  #0800 PUTW
       
    See command file "SetFreq".  A BASIC program to calculate this data is
    "CalcFreq".

    5. Interrupts on/off.  The 31.250 kHz interrupts may be masked in or out.
       The default is interrupts disabled:
       
       #0004 #9005 GETW   VERT #0040 ODER VERT  #0004 #9005 PUTW  (enable)
       #0004 #9005 GETW   VERT #FFBF UND  VERT  #0004 #9005 PUTW  (disable)
       
       Utilities for this are provided in the IQDemod directory.

       
2. Application Information
   -----------------------
   The IDdemodulator is a digital receiver.  It tunes 10.960 - 11.060 MHz.   

   The ADCs sample at a rate of 31.25 kHz.  The internal low pass filter has a
   brick-wall characteristic, is 3 db down at 9 kHz and is over 40 db down at
   13 kHz.  Thus it will typically handle appropriately shaped PSK up to about
   17.5 kbps.  However the DSP required for this probably exceeds IPS hi-level
   language capacity, and would need assembler.  Slower PSK, however is
   practical in IPS.


3. Example Programs
   ----------------
   Program: InitDemod
   ------------------
   Unjams logic (if needed), sets up AD7013 chip, and nominal RX AGC.
   
   Program: ToggleFreq
   -------------------
   Toggles LO frequency every 0.1s between 11.015 MHz and 11.025 MHz.
   Enables VCO dynamic performance to be examined.   

   Program: SetFreq
   ----------------
   Sets RX frequency to 11.020 MHz.   Use the CalcFreq utility to compute
   IPS data for other frequencies.
   
   Program: CalibIQD
   -----------------
   Program to read 2048 samples from IQDemodulator system and put them out on
   IHU-2 serial port at 38,400 baud.  First ensure that the LO frequency has
   been set up as required.  Then ensure that a dumb terminal is set to receive
   38,400 bps 8N1 data (no XON/XOFF).  Then run CalibIQD.  For subesequent
   invocations only the last block, or variations on it, need be sent.


4. Utilities
   ---------    
   Program: CalcFreq
   -----------------
   This is a BASIC program to caculate the data for any given IF frequency.
   The output is in the format for direct use by IPS.  Run the program in
   a Task Window, and copy edit it into a command file.
   
   Program: Spectrum
   -----------------
   A BASIC program to load the file "RAM:$.Spool" of IQDemodulator data
   and display its spectrum.  The file should be 8192 bytes, i.e. 2048 samples.
   Characteristics of the display are:
   
    Sample rate:          31,250 samples/s
    Number of samples:    2048
    Time span:            66 ms
    Frequency span:       15,625 Hz displayed
    Bin spacing:          15.3 Hz
    Window:               Blackman 3 point
    Bin noise bandwidth:  26 Hz
    Horizontal:           977 Hz/div (~1 kHz)
    Vertical:             10 db/div
   
   Only the I channel is displayed.  Edit the program for Q.
                    



jrm
1999 Mar 03 [Wed] 2232 utc
<end>

