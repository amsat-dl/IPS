
                         ----------------------
                         JPEG Image Compression
                         ----------------------

                           James Miller G3RUH

                               2000 Mar 31


                     * Introduction
                     * How to use JPEG
                     * Interface details
                     * Typical Application
                     * Loading JPEG code into FLASH


Introduction
------------
ARM Ltd  http://www.arm.com  have granted Amsat a free object code licence for
their JPEG Codec product in return for some "publicity".

The build described here performs greyscale compression on a 512x512 image in
about 60 ms on the IHU-2.  The code is #1960 bytes long, and uses #FE0 bytes of
workspace following the code, which you should keep free!

The code is kept in FLASH rom, but runs in RAM at #8000, converts a 256 Kb
picture located at #1000 0000 and places the JPEG output at #1 0000.  The
default "quality" is 50%, and the resulting JPEG is typically 20 Kbytes.

Compression takes 60ms, during which all IPS activity is suspended, resulting
in a loss of two pseudo-interrupts, hence the clock UHR and stopwatches
SUx lose 40ms.  Real interrupts, however, are serviced normally.

JPEG compression is supported from IPS-EM v0.07.

How to use JPEG
---------------
1. Define a remote code stub for the compression code as follows:

   0 USERCODE JPEGCOMP
      #8000 ' JPEGCOMP !

2. Extract the JPEG compression code from Flash rom (once only) by uploading
   the command file   JPEGLOAD         ###  this needs editing

3. To compress an image send the command

   JPEGCOMP

4. To download the JPEG via D-blocks, send the commands

   #504A                          ( identifier "JP" - say )
   #803C #0 GETW                  ( get start )
   #8040 #0 GETW                  ( get end+1 )
   #803C #0 GETW P-               ( length )
   FILE2D-ST                      ( start download )

   Obviously the FILE2D  program must already be loaded.

5. To download the JPEG via the serial port, send the commands

   #803C #0 GETW                  ( get start addr )
   #8040 #0 GETW                  ( get end+1 )
   MEMDUMP                        ( and send it )

   The  TXserial  programs must already be loaded (for MEMDUMP).

6. To download the JPEG via the IQmodulator, send the commands

   #803C #0 GETW     #AA1C #0 PUTW  ( start/pointer )
   #8040 #0 GETW     #AA20 #0 PUTW  ( end+1 )
             1 0     #AA24 #0 PUTW  ( go! )

   IQmod code assumed to be at #AA00  check ....!


Interface details
-----------------
The JPEG compression program is interfaced via a block of data at the start of
the code.  It is set up to sensible defaults.  Values you may wish to change
are at offsets as follows:

 offset     type     default    description
 ------------------------------------------------------------------------
  +#10      word    #1000 0000  pointer to start of our 256K image buffer
  +#3C      word       #1 0000  address of the JPEG output start
  +#40      word                current position in the output buffer
  +#51      byte            50  JPEG "quality" range 1 - 100
 ------------------------------------------------------------------------

Typical Application
-------------------
If you wish to convert a succession of pictures to JPEG, you would probably
configure the camera software to place the 256K snapshot in SRAM at #10000 to
#50000, so the word at +#10 should be set to #10000.

Then the JPEGs would go into mass RAM at #1000 0000 onwards.  So +#3C should be
initialised to #1000 0000, and after each JPEG compression, should take its new
value from the old value at +#40.

In this way a contiguous series of JPEGs will be built up.  At 25 Kb per JPEG,
this will allow some 400 JPEGs to be queued in the 8 Mb unprotected RAM.


Loading JPEG code into FLASH
----------------------------
The following sequence will burn the JPEG code into ROM 0 at offset 0x10000
IT IS ASSUMED THAT THE ROM IS ALREADY BLANK AT THIS ADDRESS.

 1.  If not running, start IPS-EM  (from 400 bps link or from ROM).

 2.  Upload the IPS program:  !IPS-EM.Work.Flash.Utils-C     (4 blocks)

 3.  Upload the IPS program:  !IPS-EM.Work.D-System.D2File-C (2 blocks)

 4.  Prepare the IHU-2 D-handler to receive data with commands:

       #8000 0  D2FILE-INST

 5.  Upload the file  UpDblocks  (inside directory !IPS-EM.Work.JPEG).  This
     is a D-block conversion of the JPEG compression code;  13 blocks.

 6.  Check upload was successful with manual command  D?
     Should return 13 13.

 7.  Append a crcc with:

     : CRCC  #FFFF  #8000 #995F JE I @B CYC2 NUN #9960 ! ;
             CRCC  WEG/AB CRCC

 8.  Burn uploaded JPEG code into blank area of rom with:
                                  ~~~~~
     0 SETROM              ( Select ROM chip; default is 0   )
     #8000 0  0 1  #1962 0 ( from #8000; into #10000; #1962 bytes  )
     FLASH-PROGRAM         ( program flash rom )

 9. You can verify the image in flash-rom with:

       0 SETROM
     : VERIFY
       #FFFF                                ( CRC seed )
       0 #1961 JE I 1 FLASH-GETB CYC2 NUN ; ( CRC loop )
       VERIFY      WEG/AB VERIFY            ( Invoke and trash )

     This should return #0000 on the stack.

<end>




