
                           P R O V I S I O N A L



              P3D IHU-2 Post Launch Data Collection Software v 1.3

                               Description

                          by James Miller G3RUH

                               2000 May 16


                         * Introduction
                         * Program Description
                         * Configuration Data
                         * Memory Assignments
                         * 8MB Mass RAM allocations
                         * Downloaded Memory Area Formats
                         * IRQ Handlers



1. Introduction
   ============
This program is loaded at Kourou into the IHU-2 and is running continuously on
the ground and at launch.

It takes pictures, jpegs them, records accelerometer and MIC data and places it
in circular buffers in 8 MB mass RAM.  All information is time-tagged.

10 minutes after separation, data collection ceases, and the 8MB mass RAM
contents are transmitted via the IQ modulator at 9600 bps FSK in asynchronous
8N1 serial format, with scrambling and NRZI encoding as per packet radio
conventions.  Descriptive information is also carried on the regular 400 bps
PSK beacon.


2. Program Description
   ===================
Once started, the program proceeds in successively enchained phases.  These are:

  LAUNCH_PHASE       from the launch pad, until separation
  SEPARATION_PHASE   from separation to separation+32s
  FLIGHT_PHASE       free flight 10 minutes
  DOWNLOAD_ST        free flight with 9600 bps data downloading

Once loaded, the program is started with the command LAUNCH_ST .  This
initialises all hardware and software flags, buffers, pointers etc.

 +---------------------------------------------------------------------------+
 | LAUNCH_ST may be given any time, and results in a clean and total restart |
 +---------------------------------------------------------------------------+

The 8MB mass RAM is /not/ purged, so its contents are preserved over an IPS-EM
or program restart, provided the IHU-2 has not been powered off.

If start-up is unsuccessful (due perhaps to flash ROM data corruption), the
value #DEAD is left on the stack.

When initialisation is complete, the 9600 bps system starts (the data is RS-232
STOP polarity), and ADC data collection commences; these tasks run via IRQ
interrupts, underneath IPS-EM.  The 400 bps PSK EB2 alternates Q-blocks and one
message block.  Finally the routine LAUNCH_PHASE is placed on the chain at
position 0.

This calls the PHOTO routine to take pictures at 5s intervals.  The separation
switch is repeatedly tested, and when a steady signal exceeding duration ~1.2s
is found, SEPARATION_PHASE is enchained.

During this phase, after physical separation, pictures continue to be taken at
5s intervals for another 32s.  The ADC data collection then stops, and then
FLIGHT_PHASE is called.

This continues to take photos at 1 minute intervals for a further 10 minutes.
On completion a differential picture is taken (dt=1.5s) and remains in SRAM
for later download.  Then DOWNLOAD_ST is called.

This inserts time of stop and buffer pointers into the 8MB memory, and starts
download of 8MB RAM at 9600 bps FSK with the call to FILE2D9600_ST . 400 bps
PSK telemetry changes to Q block plus seven message blocks telling users what
to do with the 9600 bps data.

FILE2D9600_ST initialises and enchains the program FILE2D9600 that supplies
data to the 9600 bps stream.   The program dumps an area of memory in a
sequence of D blocks.  Each call (to FILE2D9600) checks the downlink IRQ
handler status; when it is free, creates the next D-block, and resets the
9600 bps IRQ handler pointers, causing the next block to be sent.  This final
program runs continuously until dechained.

Ground stations will collect the data, which repeats every 2.5 hours, until all
512-byte D-blocks (16778) have been acquired.  If there are missing blocks, the
counter can be reset to the needed value with   nnnnn BLOCK_COUNT !

Chain position 0 is used for the above programs.  In addition position 7 is
permanently assigned to the routine IDLE, which addresses the camera pixels
randomly, maintaining a median AGC value for the imager.  Positions 1-6 are
unused.

Other routines:
---------------
PHOTO takes a photo using SNAP, corrects it (CORR) from a calibration file kept
in flash ROM, and JPEGs it using a quality value of 50.  The time (UHR) is
appended.  The camera routines are ARM coded and execute in ~1.5s per image.
During this time the IPS 20ms pseudo-interrupt system is stalled.  The program
compensates for this by measuring the elapsed time using the 31250 Hz counter
and calculating the number of missed 20ms beats.  Fake pseudo-interrupts are
then generated to correct UHR and the stopwatches using the routine ADJ_UHR .

LOADCODE extracts from flash ROM the ARM code routines for JPEG compression,
and the replacement IRQ handlers for ADC sampling and 9600bps FSK downlink.  It
returns 0 on the stack if uncorrupted code is successfully loaded.

LOADMSGS extracts message blocks from Flash ROM, and places them at
$M0BU - $M6BU inclusive.

TLM-TN is a typical telemetry handler for the 400 bps PSK engineering beacon.
It sends a sequence blocks, starting with a telemetry block (Q) and then up
to 8 message (Y) blocks.  The number of blocks in the sequence is user
defined with EB_NUM , which can take values in the range 1-9.  For example,
1 EB_NUM ! would give Q blocks only; 2 EB_NUM ! gives Q plus the first
message block.  Text blocks are uploaded with the commands Y0 , Y1 ... Y7 ;
the digit is stripped off by the handlers.  Telemetry can be turned on with
1 TLM , and off with 0 TLM .


3. Configuration Data
   ==================
The program is set up for the anticipated requirements.  However the default
values can be changed prior to sending the LAUNCH-ST command.

The 8MB memory is divided into 3 parts;  from the lowest address, these are
assigned to JPEGs, Microphone and Accelerometer.  Thus, for example, Mic area
start is the same as jpeg area end.  There are some arithmetic constraints on
these values.

( Define jpeg/mic/acc areas in 8 MB mass RAM )
  #0020  #1000 MEMJ_START !2    ( JPEG_area_start )
  #CC0C  #101D MEMJ_END   !2    ( JPEG_area_end+1 )
  #16AC  #1075 MEMM_END   !2    (  MIC_area_end+1 )
  #0000  #1080 MEMA_END   !2    (  ACC_area_end+1 )

The camera requires a 256KB area for the raw image.  The SRAM after IPS-EM is
free from #10000 to ~#7B000.  The data is placed at its start:

( Define camera raw image buffer #10000 - #50000 )
  #0000  #0001 SNAP_ADDR  !2

Photos are taken at 5s intervals.  If this is changed, then the mass RAM areas
would need to be resized.  After physical separation, the camera and ADC data
collection continues for a specified period, 32s:

  #0500 KON CAM_INT ( Photo period, 5s )
  #2000 KON RUN_ON  ( Period after separation for pictures, 32s )

The JPEG compressor "quality" can take values typically 10-95.  Experience of
terrestrial scenes shows that a value of 50 results in good images of typically
15KB - 20KB.  If this "quality" is changed significantly, mass RAM areas should
be resized.  Similarly, the estimated size of the jpeg should be altered.  This
is to prevent a jpeg image from overflowing into the microphone area.

   50 KON JQUALITY         ( Jpeg compression control )
  20000 0 JPEGSIZE !2      ( Default 20KB allowance   )

The 9600 bps FSK modulator deviation can be controlled.  The value shown
results in 4 kHz deviation, whilst 6341 results in +/- 3 kHz, to high
precision.  NRZI is used in packet radio systems to eliminate channel polarity
ambiguity.  However, NRZ can be used if desired.

( 9600 bps FSK modulator controls )
  8455 KON DEVIATION        ( dev +/- 4.0 kHz )
     1 KON NRZI             ( 1 =NRZI, 0 =NRZ format )

By default text messages are loaded from flash ROM.

     1 KON ROMMSGS          ( 1 = use, 0 = don't use )

If message loading from ROM is disabled, existing messages remain in RAM, and
should be re-loaded as necessary from the ground.

-------------

It is possible that the JPEG compressor, 9600 bps FSK and ADC IRQ handlers may
be resized or moved.  For a major event such as this the programs need editing
and reloading; the code addresses would need changing.  Though the routines are
relocatable, and can run outside of IPS-EM's 64KB workspace, they have been
placed inside it to keep the interface with IPS simpler.


4. Memory Assignments
   ==================
   (End addresses are given exclusive)

   IPS code routines
   -----------------
   #0000 - #23EE    IPS-EM
   #23EE - #41E9    IPS programs and data

   #7000 - #7FFF    8 message blocks

   ARM coded routines
   ------------------
   #8000 - #9960     JPEG compressor plus ..
   #9960 - #A940     ..  workspace
   #AA00 - #BBE8     9600 bps IQ IRQ Handler
   #BC00 - #BD48     ADC IRQ Handler
   #BD80 -#10000       free (except for IPS parameter stack)

   SRAM Remainder
   --------------
   #10000 - #50000   Camera Raw 512x512 image
   #50000 - #7BC00     free
   #7BC00 - #80000   Stacks and MMU table

   #10000000
      - #10800000    8MB Mass RAM (see below).


5. 8MB Mass RAM allocations
   ========================
                                                Area
                                              Allocation    Mass  RAM
  Item      Data Rate byte/s         %          bytes        Address
  --------------------------------------------------------------------
  Header data        --             --               32    0x0000 0000
  Camera           4000            23.3%      1,952,748    0x1000 0020
  Microphone      11719            68.2%      5,720,736    0x101D CC0C
  Accelerometers   1465             8.5%        715,092    0x1075 16AC
  --------------------------------------------------------------------
  Total           17184 byte/s    100%        8,388,608
  ------------------------------------------------------

8MB can store 488s worth of data, (8.1 minutes).

Note that the Microphone and Accelerometer allocations are in ratio 8:1, must
be divisible by 12, and initial addresses must be word aligned.

Allocations have been calculated on the following basis:

Camera
------
Takes a picture and compresses it in ~1.6s.  Typical terrestrial image is 20K
max.  Thus the /maximum/ camera rate is 12,500 byte/s.  This is however too
frequent, and a 5s rate is chosen as a compromise.

Mean camera storage requirement is 20,000/4 = 4,000 byte/s

Microphone
----------
1 channel, 12 bits, bandwidth 2.7 kHz.  Sample at 7.8 kS/s.  Store 12 bits in
1.5 bytes.  Needs unpacking on ground.

Mean microphone storage requirement is 1.5 * 7812.5 = 11,719 byte/s

Accelerometers
--------------
3 channels, 12 bit/ch, raw bandwidth 74 Hz.  Sample at 244 S/s (31250/128).

It will be far easier to store a 12 bit sample in 2 bytes.  Higher density
packing would save little.

Mean accelerometer storage requirement is 3 * 244 * 2 = 1,465 byte/s



6. Downloaded Memory Area Formats
   ===============================
Pointers are in little endian format (LSbyte at lowest address).

Header Area
-----------
The first 32 bytes of the file are allocated to information about the file:

                                  File
   Data                          Offset          Notes
   -----------------------------------------------------------------------
   Pointer to Camera area          +0        ( 0x0000 0020
     ..    to Microphone area      +4   typ. ( 0x001D CC0C
     ..    to Accelerometer area   +8        ( 0x0075 16AC
   Final CAM area pointer         +12   )
     ..  MIC area pointer         +16   )  circular buffers
     ..  ACC area pointer         +20   )
   Stop time                      +24   6 byte TIME tag  (see below)
   not used                       +30   2 bytes set to 0
   -----------------------------------------------------------------------

Camera Area
-----------
Chunks consists of successive JPEG images with appended TIME tag.  The buffer
area is circular; the pointer is reset to the start when less than 20K remains
free.

Jpeg chunks:

  JPEG start id: 0xFF 0xD8 (jpeg SOI)
  JPEG data    : typically 15-20K bytes until ...
  JPEG end id  : 0xFF 0xD9 (jpeg EOI)
  TIME tag     : 6 bytes; ss, SS, MM, HH, DD(l), DD(h)

where:

   DD(h) = AMSAT DAY number DIV 256   )
   DD(l) = AMSAT DAY number MOD 256   )  IPS
   HH    = Hour    0-23               )  UHR format
   MM    = Minute  0-59               )  Day 0 = 1978 Jan 01
   SS    = Seconds 0-59               )
   ss    = 100ms   0-98               )

When data collection stops, a final TIME tag is placed at header+24,
and the 4 byte camera pointer minus 0x1000 0000 is deposited at header+12.

Microphone Area
---------------
MIC ADC samples are 12 bits, and are packed 2 samples to 3 bytes.

   MSB                  LSB
  +-----------+-----------+
  |  M0[7:4]  :  M0[3:0]  |  byte 0       |       M0 = 1st MIC sample
  +-----------+-----------+               |       M1 = 2nd MIC sample
  |  M1[3:0]  |  M0[11:8] |  byte 1       |
  +-----------+-----------+               v
  |  M1[11:8] :  M1[7:4]  |  byte 2    address
  +-----------+-----------+          increasing

Sample rate is 7812.5 S/s.

The buffer is circular.  When data collection stops, the 4 byte buffer pointer
minus 0x1000 0000 is deposited at header+16.

Accelerometer Area
------------------
Accelerometer ADC samples are 12 bits, and are packed one sample to 2 bytes,
each channel following the next.

   MSB                  LSB
  +-------------+-------------+
  |  ADCx[7:4]  :  ADCx[3:0]  |  byte 0
  +-------------+-------------+
  |     0       |  ADCx[11:8] |  byte 1          |       ADCx, ADCy, ADCz =
  +-------------+-------------+                  |       accelerometer, axes
  |  ADCy[7:4]  :  ADCy[3:0]  |  byte 2          |       x, y and z.  P3D axes
  +-------------+-------------+                  v       are similar.
  |     0       :  ADCx[11:8] |  byte 3       address
  +-------------+-------------+             increasing
  |  ADCz[7:4]  |  ADCz[3:0]  |  byte 4
  +-------------+-------------+
  |     0       :  ADCz[11:8] |  byte 5
  +-------------+-------------+

Sample rate is 244.1406 S/s  (31250/128)

The buffer is circular.  When data collection stops, the 4 byte buffer pointer
minus 0x1000 0000 is deposited at header+20.


7. IRQ Handlers
   ============

112,500 Hz Interrupt
--------------------
Services IQ modulator to generate 9600 bps FSK in blocks given user defined
pointers.  A patch in the IQmod handler points to new code.  For details, see
source listing.

Under IPS-EM, this handler uses 12.2% of machine time.


31,250 Hz Interrupt
-------------------
MIC and accelerometer data is collected on interrupts.  This is so that it can
be accurately paced.  A patch in the IQdemod handler points to new code.  For
details, see source listing.

The four ADC channels  MIC, Ax, Ay, Az  are sampled in turn on successive
interrupts and stored locally until the 128th call when the 3 are written to
output circular buffer.

Thus, on each 31,250 Hz call:

  - increment fast monotonic counter
  - send ADC conversion request and ...
  -  ... read ADC data (note: result of a /previous/ conversion)
  - if MIC: pack bytes into circular buffer.
  - if Ax,Ay,Az: pass value to local buffer
  - every 128th call (244 Hz) save Ax,Ay,Az 16-bit values to circular buffer.

Under IPS-EM, the ADC handler uses ~2% of machine time.

<end>
