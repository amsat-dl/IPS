
                      IHU-2 Complete IPS Re-Flash
                      ---------------------------

                           by James Miller


These notes describe the procedure to reprogram ROM 0 with IPS-EM and related
material.

Completely reprogramming ROM 0 proceeds in several stages:

  Stage 1. IPS-EM
  Stage 2. Code Routines
  Stage 3. Applications  (Launch and post-launch software)
  Stage 4. Restart

These stages are described in full below.  If you know what you are doing,
there are some short cuts, but they save little time.  You are advised to
stick to the procedure ...

  Note: the camera calibration file is kept in ROM 1, and the flash procedure
  is as described in the document   !IPS-EM.Work.Flash.ReadMe .

Stage 1. IPS-EM
===============
1.  Reset the IHU-2

2.  Follow the instructions in file   !IPS-EM.Docs.IPSinROM

Stage 2. Code Routines
======================
The following assumes Flash utilities and D2File are resident from stage 1.

1. Flush the area #8000 - #C000 with the command:

      0 #8000 !B  #8000 #8001 #3FFF L>>>


2a.  Prepare the IHU-2 D-handler to receive data with command:

      #8000 0  D2FILE-INST

2b.  Upload  "JPEG.UpDblocks"  to the IHU-2 (13 blocks)

2c. Check upload was successful with manual command  D?
    Should return 13 13.


3a. Prepare the D-handler to receive data with the command:

      #AA00 #0  D2FILE-INST

3b. Upload   FM-9600.UpDblocks  (10 blocks)

3c. Check upload was successful with manual command  D?
    Should return 10 10.


4a. Prepare the D-handler to receive data with the command:

      #BC00 #0  D2FILE-INST

4b. Upload   ADC.UpDblocks      (1 block)

4c. Check upload was successful with manual command  D?
    Should return 1 1.


5. Append a CRCC with:

    : CRCC
      #FFFF
      #8000 #BFFD JE I @B CYC2 NUN #BFFE ! ;
      CRCC WEG/AB CRCC

6.  Burn uploaded data with:

      0 SETROM              ( Select ROM chip; default is 0   )
      #8000 0  0 1  #4000 0 ( from #8000; into #10000; #4000 bytes  )
      FLASH-PROGRAM         ( program flash rom )

7. Verify the image in flash-rom with:

    : VERIFY
      #FFFF                                ( CRC seed )
      0 #3FFF JE I 1 FLASH-GETB CYC2 NUN ; ( CRC loop )
      VERIFY      WEG/AB VERIFY            ( Invoke and trash )

    This should return #0000 on the stack.

Stage 3. Post Launch Software
=============================
1. Reset the IHU-2

2. Upload the following binary/command/program files in order:

    Note: suffix "-C" means use white-space stripped version (for speed)

   Name         Blx  Type       Comment
   -------------------------------------------------------------------
   BootRomIPS    1    Bin       Starts IPS-EM
   Chunk-A1      1    IPS       Creates chunk header
   TXserial-C    1    IPS       Serial downlink (for ground test)
   FL_Utils-C    4    IPS       Flash utilities
   D2File-C      2    IPS       ) D-block
   File2D-C      2    IPS       ) handlers
   CAM_UTILS     8    Bin       Camera code routines
   EB1-C         3    IPS       EB1 regenerator
   TLM-C         3    IPS       EB2 telemetry handler
   MSGS/IPS      7    IPS       Text messages
   LAUNCH-C      9    IPS       Main launch program
   CHUNK-A0      1    IPS       Completes chunk header data
   RAM2ROM-C     1    IPS       Burn chunk; should return #0000 on stack
   MSG2ROM       1    IPS       Burn messages
   -------------------------------------------------------------------
   

Stage 4. Start Post-Launch Software
===================================

1.  Reset the IHU-2

2.  Upload the binary program:  BootRomIPS  (1 block; restarts IPS-EM)

3.  Upload the IPS program GO

4.  Adjust clock.


jrm
2000 May 17 [Wed] 1420 utc

