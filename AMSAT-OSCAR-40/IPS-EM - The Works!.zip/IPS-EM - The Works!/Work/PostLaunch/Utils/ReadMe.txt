
                 AMSAT P3D Post Launch Software Utilities
                  
                          by James Miller G3RUH
                  
                               2000 Mar 25



Summary
=======
These BASIC programs are simple utilities to process the post-launch
9600 bps raw data dump.

Source information will be a file or files containing lots of D-blocks.
However the framing will be arbitrary, there will be corruptions, and blocks of
noise.

These programs take the file(s), extract the D-blocks, convert the D-blocks to a
file, decompose the file into JPEG, MIC and Accelerometer parts, and then
re-format the parts as required.


Program Descriptions
====================

RawD2file
---------
Extracts D-blocks from a raw 9600 baud downlinked data file(s) and converts
them to the original 8MB file as RAM file "OH".  The raw data files should be
in the directory "Utils.Downloads".

Complains if there are holes.  If so, you must command the downlinker to
resume from the missing block(s), with    nn BLOCK-COUNT !

OH_Split
--------
Takes the file "OH" and extracts the JPEG, MIC and accelerometer parts
to HD as:

  $.tmp.JPEGraw
  $.tmp.MICraw
  $.tmp.ACCraw

JPEGxtract
----------
Processes JPEGraw file and extracts the JPEGs.  Places them in a ZIP file
P3DJPG/ZIP .  The jpeg filenames shows the time the image was taken, e.g.
HHMMSS/JPG    File is placed on HD in directory $.tmp.

MICxtract
---------
Processes MICraw file and converts to a .WAV file in RAM disc.  The file is
MIC/WAV , and the RIFF sound format  16-bit linear, signed, mono.



GO!
---
This command file will do all the above automatically.  The RAM disc should have
8MB free space.

--------------

The following are for use in case there are problems with "RawD2file".

Dextract
--------
Extracts up to 10MB worth of D-blocks from raw 9600 baud downlinked data
file(s).  The raw data file(s) should be in the directory "Utils.Downloads".

The output is file "DOH!" to RAM disc, which needs 10MB free space.


D2file
------
Takes the file of D-blocks and extracts the original 8MB file as RAM file "OH".
Complains if there are holes.  If so, you must command the downlinker to
resume from the missing block(s), with    nn BLOCK-COUNT !

You can also do D-block to file extraction using the "regular" D-block manager,
but the blocks must be aligned modulo 512 in the source file.

jrm
2000 Mar 28 [Tue] 1941 utc
