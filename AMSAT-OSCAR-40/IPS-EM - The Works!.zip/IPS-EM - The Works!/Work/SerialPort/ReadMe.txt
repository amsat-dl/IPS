Serial Port utilities
---------------------
The IHU-2 RS232 serial port is a 3-wire connection; TXD, RXD and GND.  It can be
driven by a dumb terminal, but offers no handshaking facilities.

Serial ports are a constant source of frustration.  In this case, your dumb
terminal may /possibly/ not transmit to the IHU-2 unless the latter has CTS
asserted.  One way to ensure this is to join CTS to DTR, pin 8 to pin 4 at the
computer.  This can be done using a break-out box, or more simply by wiring to
the underside of the IHU-2 PCB, assuming a fully populated RS232 cable.

Note that pins 4 & 6 should be joined at the IHU-2 in order to power the RS232
driver chip.  However if the computer supplies +5v on pin 4 (DTR), this link
can be omitted. 


File: TXserial and TXserial-C
-----------------------------
These files contains IPS routines which send data to the RS232 serial port for
test purposes, notably big image dumps from the camera.  TXserial-C is a
white-space stripped version of TXserial.


MEMDUMP
 Call:     <start LSW><start MSW>  <end+1 LSW><end+1 MSW>  MEMDUMP
 Function: Dump memory to SA-1100 UART serial port.
 
 Description:
 MEMDUMP enchains a handler MD at position 6.  This continuously checks the
 state of the UART;  when free it gets a byte from memory, sends it
 to the UART, and increments an address counter.  MD then checks for dump
 completion and dechains itself.
 
 You may stop a dump at any time by sending the command 6 AUSH .
 
 Example:  To dump 256K from #1000 #0000 to #1003 #FFFF  (typically camera)
 
           #0000 #1000  #0000 #1004 MEMDUMP 


TXBYTE
 Call:     <byte> TXBYTE
 Function: Send a byte to the SA-1100 serial port
 
 Description:
 Simple routine reads UART FIFO status from address 0x8005 0020.
 Checks if TX FIFO is free, and when it is, calls PUTB to write the byte
 to UART.
 
 Example:  Repeatedly transmit the character "B"
 
           : B #42 TXBYTE ;  1 EINH B


File: RXserial and RXserial-C
-----------------------------
This file contains routines to read bytes from the RS232 serial port.  Once
<address> RXSERIAL-ST has been called the serial port is scanned every time
around the chain.  Whenever a byte is read it is placed into memory at the
32-bit <address> and the address is incremented.  The process continues until
10s has elapsed with no RX activity.  RXserial-C is a white-space stripped
version of RXserial.

RXSERIAL-ST
 Call:     <Address LSW> <Address MSW> RXSERIAL-ST 
 Function: Initiate read serial RX data until timeout.
 
 Description:
 Initialises serialport to 115,200 baud and flushes any garbage.  Then it
 sets a 10 sec timer and enchains RXSERIAL at position 0.

RXSERIAL
 Call:     This routine is placed on the chain
 Function: Read serial port, deposit data. 

 Description:
 If the 10s timer has matured, then the routine dechains itself.  Otherwise the
 UART status byte is checked to see if a character is available.  If so it is 
 deposited at the 32-bit address given by RXADDR, the address is incremented
 and the 10s timer restarted.
 

jrm
2000 Feb 07 [Mon] 1327 utc