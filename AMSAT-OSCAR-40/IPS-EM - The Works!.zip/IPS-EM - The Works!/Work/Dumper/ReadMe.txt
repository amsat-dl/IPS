               How to make IPS-EM downlink your own blocks
               -------------------------------------------
Read  !IPS-EM.Docs.I/O  for a description of the output system.

To make IPS-EM  output material on the EB-2 beacon:

  1. Create a routine (say MYPROG) which will, when called:
  
     a. Marshall its downlink material and place
        it in the 512 byte buffer $EBU
     b. call ETRANSMIT which will then append the block crc
        and start the downlink.
  
  2. Place your routine's address into the constant A-COMPOSER , e.g.
  
        ' MYPROG ? A-COMPOSER !
     

Your routine will now be called whenever the downlink is free, approximately
every 12.64 s.

Examples are included in this directory:

  Dump         Dumps 512 bytes pointed to by the variable DUMP
  DumpStop     Stops any dump process
  DumpReStrt   Restarts dump process
  DumpAddr     Changes dump pointer

Downlink blocks can be displayed in the Raw window of a telemetry program.

From !TLM13 the currently displayed block can be saved as a binary by clicking
SELECT (left) in the window.  [Shift-SELECT will open the Blocks directory].

Successive blocks can be saved by choosing Logging from the Menu.  Remember
to set the Log all option, also from the Menu.


jrm
1999 Mar 02 [Tue] 2220 utc
<end>
