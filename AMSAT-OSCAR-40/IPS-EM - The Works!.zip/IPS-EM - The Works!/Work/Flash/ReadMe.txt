                       IHU-2 Flash Eprom Utilities

                          by James Miller G3RUH



                   Index  Section
                   -----------------------------------
                     1.   Introduction
                     2.   About Addressing
                     3.   Basic Operations
                     4.   Flash Routine Descriptions
                   -----------------------------------

1. Introduction
   ------------
File "FL_Utils" contains the tools you need to read/write/erase/verify the
IHU-2 Flash ROM system; but  it is 20 blocks long.  However ...

"FL_Utils-C" is the identical material stripped of white space, and is only 4
blocks long.  You should load it in its entirety;

The principal utilities are:

   SETROM            Choose ROM bank 0 or bank 1
   FLASH->0          Write 0 in all locations
   FLASH-ERASE       Bulk erase all locations
   FLASH-BLANK       Test for all locations erased
   FLASH-PROGRAM     General purpose programmer

In addition there are various subroutines, of which you might need:

   FLASH-GETB        Read a byte from flash rom
   FLASH-BLANK-N     Check an area of rom erased
______________________________________________________________________________

2. About Addressing
   ----------------
The IHU-2 has 2x 256K flash eprom devices.  (Early versions had 1x128K).

Although byte organised, each Flash rom byte is word addressed.  Also, the
address space is not fully decoded, so that addresses wrap around.  Denoting
the two 256K roms by "A" and "B", the explicit address mappings are:

  Address Start       256K
 -------------------------------
  0x1080 0000          A
  0x1090 0000          A  repeated
  0x10A0 0000          B
  0x10B0 0000          B  repeated
 -------------------------------

Thus contiguous addresssing is possible transparently by adopting a
base address of 0x1090 0000

In principle the roms could be read or written as though they were one device.
In practice it is likely that flexibility will be needed to write/erase them
separately.  One might contain the essentially static Camera calibration file
(256K long) and the other IPS itself and perhaps evolving utilities.

Thus the Flash Utilities assume you will want to write/erase to the two eprom
devices separately.

Rom space is always user-specified as a byte offset from the currently chosen
rom's start.  Conversion of this logical address to the physical address is
hidden from you, by routine FLASH-ADDR.  However this can be bypassed.

NOTE:  In commands, all addresses and byte counts are specified by the user as
32-bit (2-word) quantities:  <LS word> <MS word>.
______________________________________________________________________________

3. Basic Operations
   ----------------

3.1 Selecting a Rom device
    ----------------------
The Roms are designated 0 and 1; device 0 is at the lowest address.  Select a
device with, e.g.

    0 SETROM    (Select ROM 0)

The default device is 0.


3.2 Erasing Flash Rom
    -----------------
Invoke the following 3 commands:

   FLASH->0           ( Write 0 in all locations      )
   FLASH-ERASE        ( Bulk erase all locations      )
   FLASH-BLANK        ( Test for all locations erased )

The first command programs all locations to zero;  AMD/TI/Intel say this is
essential.  The second erases all locations to the blank pattern 0xFF.  Finally
the rom is checked for complete erasure.  In the event of an error condition,
diagnostics are left on the stack.


3.3 Checking for erasure
    --------------------
An area to be programmed must be in the blank condition.  Check the entire
rom with:

  FLASH-BLANK

Check a limited area of rom by specifying an offset address into the rom, and
the number of bytes to be checked:

 <address> <number of bytes> FLASH-BLANK-N

If either of these fails, the offset address into the rom will be left on
the stack.  The byte's value can be read directly with FLASH-GETB


3.4 Programming Flash Rom
    ---------------------
To blow the rom, first check for erasure (as above).  Then specify a source
address, destination rom offset, and number of bytes to be programmed.

For example, to copy 256K bytes (for example a camera calibration file) from
mass RAM location 0x1060 0000 to rom "B":

  1 SETROM
  #0000 #1060 ( from )
  #0000 #0000 ( to )
  #0000    #4 ( size )
  FLASH-PROGRAM

If this fails, diagnostics will be left on the stack.
______________________________________________________________________________

4. Flash Routine Descriptions
   --------------------------

4.1 FLASH-ERASE
    -----------

 Call:  FLASH-ERASE (no parameters)

Refer to the flow chart.  The erase command is given up to 1000 times;  then
the device is considered to be defective, and the routine exits, leaving on the
stack the offset address of the byte that refused to be wiped.  The typical
number of erase cycles is 50.  This number can be inspected with PULSECOUNT @
immediately after erasure.

After each erase cycle, addresses are checked for erasure from the previously
successful address onwards, as recommended in the AMD documentation.  This
speeds up the procedure considerably, because already verified addresses are
skipped.


4.2.1 FLASH-BLANK-N
      -------------

  Call:  <offset> <n-bytes> FLASH-BLANK-N

Checks specific locations in the selected device for erasure (0xFF).  Halts if
an unerased location is found, leaving its offset address on the stack.  Read
the location's contents with FLASH-GETB.

4.2.2 FLASH-BLANK
      -----------

 Call:  FLASH-BLANK (no parameters)

Checks all locations in the selected device for erasure (0xFF).  Halts if an
unerased location is found, leaving its offset address on the stack.  Read the
location's contents with FLASH-GETB.

4.2.3 FLASH-GETB
      ----------
      
 Call:  <offset> FLASH-GETB
 
Reads a byte at <offset> into currently selected device.
     

4.3 FLASH-PROGRAM
    -------------

 Call: <From address> <To offset address> <Number of bytes > FLASH-PROGRAM

Refer to the flow chart.  The calling parameters are taken from the stack and
preserved.  Then the routine loops until the byte count equals the number of
bytes to be programmed.

The outer handler calls FLASH-WRITE which implements the AMD recommended flash
write procedure.  This routine exits when the byte is succesfully written
(verified) or if the number of attempts exceeds 25.

If PULSECOUNT exceeds 25, FLASH-PROGRAM exits immediately, leaving the failed
offset address on the stack.


1999 May 28 [Fri] 1158 utc
<end>


