!IPS-EM.Docs.Flowcharts.Readme                                     2000 May 04


These flow charts are in Acorn Drawfile format.  They can be read on an IBM-PC
using CorelXara or Oak-Draw for Windows.

IPS        IPS-EM Top Level
EB2        EB transmit interrupt handler (*)
CMD        CMD receive interrupt handler

EB2_OLD    Original EB2 handler


(*) The MSH of the EB2 shift register in the FPGA-HI chip gets corrupted when
    there is intense bus activity.  This new EB handler is byte oriented and
    uses only the LSH.