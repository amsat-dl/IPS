M-3205 Meinzer IPS32 Computer for Windows
-----------------------------------------

What's In This Zip?
-------------------

M3205.EXE               - The Executable Application

README.TXT              - This File

IPS32-M.BIN             - Kernel Binary for End-User IPS32-M
IPS32-M.SRC             - Source Code for IPS32-M to be compiled by IPSY32-M
IPSY32-M.BIN            - Kernel Binary for IPSY32-M
IPSY32-M.SRC            - Source Code for IPSY32-M to be compiled by IPS32-M
IPS32-A.SRC             - Source Code for IPS32 for the Acorn Risc Computer
                        - to be compiled by IPSY32-M (Untested)
A-Bin                   - Kernel Binary for End-User ISP32-M for the
                        - Acorn Risc Computer (Untested)
AASM-Y.SRC              - Source Code of ARM Assembler to be compiled by IPSY32-M
GS2005.SRC              - IPS Source Code for AO-40 Tracking Program

\SRC                    - The Delphi Pascal Source Code for M3205

\DOC\Syspage Map.TXT    - IPS32-M Memory Map
\DOC\M-3205.TXT         - M3205 Engine Specification (by KM modified by PW)

\HISTORY\HISTORY.TXT    - Notes about the files in the \HISTORY folder
\HISTORY\IPSX32-M.BIN   - Kernel Binary for IPSX-32
\HISTORY\IPSX32-M.SRC   - Source Code for IPSX32 to be compiled by the Builder
\HISTORY\IPS32-M-X.SRC  - Source Code for IPS32-M to be compiled by IPSX32
\HISTORY\IPS-X.ZIP      - 16 bit version of IPS-X, some useful documentation
\HISTORY\DOC            - Some diagnostic files for IPSX32-M
\HISTORY\16BIT          - 16 bit versions of IPS for MSDOS, some useful documentation

Instructions
------------

On first running the application, click on Tools menu, then Options.
The Options form will be displayed.

Select the kernel binary that you wish to load. If you don't see the file 
then press the browse button (the one with 3 dots), and locate it.

Once you have selected the kernel, the application will remember where it 
is located.

Now setup your clock offset from UTC. EST = -5. You can use fractions of hours 
such as 6.5 if required.

If you want your clock to be exactly in tune with Windows, then check
the Force UHR to System Time box. When this is not checked then the clock is a 
free-running standard IPS clock. This is updated every 20ms psuedo interrupt.

The time between psuedo interrupts is determined by a count of times
through the inner interpreter loop. You can select the interval in
the 20ms Interrupt Interval edit box. By tuning this value for your
computer you can get close to real time.

If you want to change kernels then go back to the Options form and
select the new binary. Then close the Options form. Now select Restart 
from the File menu. This will restart the engine with the newly selected 
binary. 

Selecting Re-Start whilst any kernel is running will reload the kernel
and start from fresh.

The specification requires that DVFLAG be used to indicate that the screen 
needs updating. Now there is an option to either use the specified DVFLAG
method or the old IPSDOS method of updating the screen in PokeByte (faster).
I don't take a position on this, use whatever method you prefer.


You can now use IPS as the old IPSDOS.


Implementation
--------------

This version implements Interface specification Rev.4 2005.03.24 (PW Mod)


What's New In This Version
--------------------------

1.0.0 - February 16, 2005 - Initial Release
1.0.1 - February 18, 2005 - About Screen & Copyrights added
                          - IPSXBuilder Info Filenames changed
1.0.2 - February 22, 2005 - Speed Improvements
 			  - Fixes made to keyboard and screen handling, 
			  - speed improvements.
1.0.3 - February 22, 2005 - Memory Leak Fixed
1.0.4 - February 24, 2005 - Thread removed, engine now in ufrmM3205
                          - Start button removed, menu item Start/Re-Start
                          - added
                          - Options form added
                          - Clock options added
                          - rp-loop, tr-loop, 3swap added
1.0.5 - February 25, 2005 - code_pdiv fixed
                          - +! now implemented as rcode routine
                          - Overwrite keyboard mode now default 
1.0.6 - February 25, 2005 - double spaced lines fixed on file read
			  - fix to +! 
1.0.7 - February 25, 2005 - fix to P- 
1.0.8 - February 25, 2005 - $CCODES changed to $ncodes in builder
			  - and IPSX32-M.SRC
			  - Formatting changes to TV Screen 
1.0.9 - March 17, 2005    - SYSPAGE address changes
                          - DVFLAG added at #440
                          - $H removed from syspage now var
                          - P1 removed from syspage now var
                          - LOADFLAG moved from #42D to #444
                          - P2 moved from #43C to #438
                          - Return Stack moved from #5F0 to #4F0
                          - IPS Starts at #500
                          - $Os moved from #464 to #468
                          - Stop Watches moved from #434 to #450
                          - $TVS removed, now TV0 is used instead
                          - DV definition and use thereof added
                          - $DEP renamed $DEPW
                          - POLYNAME seed sequence and return result order
                          - changed
                          - CLS renamed AWEG
                          - $LL removed, restriction removed from WEG/AB
                          - $SIZE concept added, $SL, $ML now definitions
                          - $LANG and multiple language error messages dropped
                          - Sequence of items in $ccodes, $ncodes changed
                          - retex 4th
                          - F-VERGL now same as 16-bit version, i.e. 256 based
                          - feld and ~ now force to 4 byte boundary
                          - $cscan no longer code routine, its written in IPS
                          - $scode no longer used by IPS-M, still IS by IPS-X
                          - $tue removed, compiler modified
                          - L>>> removed, >>> extended to move large numbers
                          - of bytes, provided number of bytes is >0, i.e.
                          - negative or zero numbers move nothing. The moves
                          - are broken up into 64 byte moves per atomic
                          - operation, then PPC moved back
                          - As all flags are 4 byte, ! and @ are now used
                          - instead if !B and @B
                          - CYC2 code routine added
                          - oscli remoed
                          - minor change to ENTRYSETUP
                          - S-ON removed
1.1.0 - March 18, 2005    - Formatting changes
                          - $SIZE, DVFLAG & $H initialisation bugs corrected
                          - Debug $h setting line removed
1.1.1 - March 21, 2005    - Return Stack moved to $5F0
1.1.2 - March 23, 2005    - $scode now in IPS for IPSX as well
                          - Various 4 byte boundary fixes (TLITERAL)
                          - Change to Init of stopwatches in IPS-M/IPS-X
                          - Direct Video Access (PokeByte) or DVFLAG now an Option
                          - H4INC/h4inc definitions changed
                          - IPS-M Splash format changed to same as IPS-X
1.1.3 - March 24, 2005    - All previous versions compiled using IPSX32-M       
                          - Changes made to allow compilation by IPSY32-M       
                          - Comments changed to single line for IPS-Y reasons   
                          - Core Portable IPS Section added                     
                          - Implementation options added for $CSCAN, $SCODE,    
                          - OSCLI & DEFCHAR                                     
                          - Info Splashes made generic                          
                          - Filename changed from IPS32-M-Y.SRC to IPS32-M.SRC  
                          - IPS32-M-X.SRC and IPSX32-M.SRC Deprecated
                          - Related files added to \HISTORY
                          - $scode and $cscan support reinstated
1.1.4 - March 24, 2005    - IPS32-M for the Acorn Risc Computer added

Comments
--------

Please send any bug reports to
pwillmott@northrock.bm

--------------------------------
Paul Willmott
March 24, 2005
